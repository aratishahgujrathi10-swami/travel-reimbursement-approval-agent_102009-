# Mock Travel Reimbursement Policy (Prototype)

This document is **sample/mock** policy text for a prototype agent.

## Eligibility
- Categories may be reimbursed only when explicitly allowed in the approval matrix.
- Each claim is evaluated using:
  - Eligibility rules (approval matrix)
  - Limits/caps (per diem and max caps)

## Limits
- **Per-diem** is applied as `per_diem_amount * travel_days` (when configured in limits).
- **Max cap** applies as an absolute upper bound for the category/region.

## Receipt Requirements
Receipts are required per category:
- Hotel: receipts required for Hotel and Meals (Meals for incidental expenses)
- Meals: receipts required for Meals
- Taxi: receipts required for Taxi

## Manual Review Triggers
Route to Manual Review when:
- Required receipts are missing
- Date range is invalid
- Potential duplicate is detected
- Any other ambiguity is detected by the agent
