from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any

from .schema import Claim


@dataclass
class PolicyStore:
    policy_dir: str

    def _read_json(self, filename: str) -> dict[str, Any]:
        path = os.path.join(self.policy_dir, filename)
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _read_text(self, filename: str) -> str:
        path = os.path.join(self.policy_dir, filename)
        with open(path, "r", encoding="utf-8") as f:
            return f.read()

    def get_policy_context(self, claim: Claim) -> dict[str, Any]:
        """
        Returns the relevant subset of policy for deterministic limit checks.
        """
        approval_matrix = self._read_json("approval_matrix.json")
        limits = self._read_json("limits.json")
        policy_md = self._read_text("travel_policy.md")

        # Eligibility: based on category and region
        matrix_key = f"{claim.category}:{claim.region}"
        eligibility = approval_matrix.get(matrix_key, approval_matrix.get("default", {}))

        # Caps: based on category and region
        region_caps = (
            limits.get("regions", {}).get(claim.region, {})
            if isinstance(limits.get("regions", {}), dict)
            else {}
        )
        cat_caps = region_caps.get("categories", {}).get(claim.category, {})

        caps = {
            "max_cap": float(cat_caps.get("max_cap", 0.0)),
        }

        per_diem_amount = cat_caps.get("per_diem_amount")
        per_diem_days = int(cat_caps.get("per_diem_days", 0))

        per_diem = {}
        if per_diem_amount is not None:
            per_diem = {"amount": float(per_diem_amount), "currency": claim.currency}
        else:
            per_diem = {"amount": None, "currency": claim.currency}

        return {
            "policy_markdown": policy_md,
            "eligibility": {
                "allowed": bool(eligibility.get("allowed", False)),
                "reason": eligibility.get("reason"),
                "approval_route": eligibility.get("approval_route", "Standard"),
            },
            "caps": caps,
            "per_diem": per_diem,
            "per_diem_days": per_diem_days,
            "rule_basis": {
                "matrix_key": matrix_key,
                "cat_max_cap": caps["max_cap"],
                "per_diem_days": per_diem_days,
            },
        }
