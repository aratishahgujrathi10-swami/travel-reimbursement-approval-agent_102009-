from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field


Decision = Literal["Approve", "PartiallyApprove", "Reject", "ManualReview"]


class ReceiptMeta(BaseModel):
    receipt_id: str
    vendor: str
    date: str  # ISO date string
    amount: float
    category: str
    currency: str = "USD"
    attached: bool = True


class Claim(BaseModel):
    claim_id: str
    employee_id: str = "E123"  # mock
    employee_name: str = "John Doe"  # mock
    travel_start_date: str  # ISO date
    travel_end_date: str  # ISO date
    region: str  # e.g., "US", "EU"
    category: str  # e.g., "Hotel", "Meals", "Taxi"
    total_requested_amount: float
    currency: str = "USD"
    receipts: list[ReceiptMeta] = Field(default_factory=list)

    # Optional fields to make ambiguity scenarios testable
    has_itemized_invoice: bool = False
    declared_reason_for_exception: Optional[str] = None

    # Mock previous claims to support duplicate detection
    possible_duplicate_of: Optional[str] = None


class PolicyReference(BaseModel):
    source: str  # file name or section id
    section: str
    excerpt: str


class DecisionOutput(BaseModel):
    decision: Decision
    approved_amount: float
    deductions_rejected: float

    missing_documents: list[str] = Field(default_factory=list)
    policy_references: list[PolicyReference] = Field(default_factory=list)

    reason_codes: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0)

    short_explanation: str
    tool_trace: list[dict[str, Any]] = Field(default_factory=list)
