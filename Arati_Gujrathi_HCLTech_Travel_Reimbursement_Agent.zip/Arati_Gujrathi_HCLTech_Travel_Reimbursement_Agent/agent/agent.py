from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .policy_store import PolicyStore
from .rules import compute_confidence_and_decision
from .schema import Claim, DecisionOutput
from .tools import Tools


@dataclass
class AgentConfig:
    manual_review_on_missing_docs: bool = True
    manual_review_on_conflicts: bool = True
    # In this prototype, “confidence routing” is deterministic.
    manual_review_confidence_threshold: float = 0.55


class TravelReimbursementAgent:
    def __init__(self, policy_store: PolicyStore, previous_claims: list[dict[str, Any]] | None = None, config: AgentConfig | None = None):
        self.policy_store = policy_store
        self.tools = Tools(policy_store, previous_claims=previous_claims)
        self.config = config or AgentConfig()

    def evaluate_claim(self, claim: Claim) -> DecisionOutput:
        tool_trace: list[dict[str, Any]] = []

        # 1) Validate dates (cheap rule)
        missing_dates = self.tools.tool_validate_dates(claim, tool_trace)
        if missing_dates:
            # missing/invalid dates is ambiguous in this demo => manual review
            return DecisionOutput(
                decision="ManualReview",
                approved_amount=0.0,
                deductions_rejected=0.0,
                missing_documents=missing_dates,
                policy_references=[],
                reason_codes=["date_range_invalid"],
                confidence=0.3,
                short_explanation="Travel date range is missing/invalid; route to Manual Review.",
                tool_trace=tool_trace,
            )

        # 2) Tool A: receipt completeness
        receipt_result = self.tools.tool_receipt_completeness_check(claim, tool_trace)
        missing_receipts_categories = receipt_result["missing_receipts_categories"]

        missing_documents: list[str] = []
        # In this demo: missing categories are treated as missing documents
        if missing_receipts_categories:
            missing_documents.extend([f"Missing receipt(s) for category: {c}" for c in missing_receipts_categories])

        # 3) Tool B: policy lookup + limits checks
        policy_and_limits = self.tools.tool_policy_lookup_and_limits_check(claim, tool_trace)
        policy_context = policy_and_limits["policy_context"]
        limits_result = policy_and_limits["limits_result"]

        eligibility_allowed = bool(limits_result.get("allowed", False))
        approved_amount = float(limits_result.get("approved_amount", 0.0))
        deductions_rejected = float(limits_result.get("deductions_rejected", 0.0))
        disallow_reason = limits_result.get("disallow_reason")

        # 4) Optional Tool C: duplicate detector
        dup_result = self.tools.tool_duplicate_detector(claim, tool_trace)

        # 5) Compute decision deterministically
        # In this demo, duplicate suspicion pushes Manual Review (not Reject) because duplicates can be legitimate.
        if dup_result.get("is_duplicate_suspected"):
            # Treat as conflict/uncertainty
            decision, amt, explanation, confidence, reason_codes = (
                "ManualReview",
                0.0,
                "Potential duplicate claim detected; requires manual verification before approving reimbursement.",
                0.45,
                ["potential_duplicate"],
            )
            tool_trace.append({"tool": "duplicate_detector_policy", "duplicate_of": dup_result.get("duplicate_of")})
        else:
            # Use shared function
            from .rules import compute_confidence_and_decision  # local import to avoid cycles

            decision, amt, explanation, confidence, reason_codes = compute_confidence_and_decision(
                claim=claim,
                missing_documents=missing_documents,
                eligibility_allowed=eligibility_allowed,
                deductions_rejected=deductions_rejected,
                allowed_amount=approved_amount,
                tool_trace=tool_trace,
            )

        # 6) If decision is Approve/PartiallyApprove but confidence is low, manual review
        if decision != "ManualReview" and confidence < self.config.manual_review_confidence_threshold and self.config.manual_review_on_conflicts:
            decision = "ManualReview"
            amt = 0.0
            explanation = "Low-confidence evaluation due to policy/receipt ambiguity; routed to Manual Review."
            reason_codes = list(set(reason_codes + ["low_confidence"]))
            confidence = max(confidence, 0.25)

        policy_refs = [
            {
                "source": "policy/approval_matrix.json",
                "section": f"matrix_key={policy_context['rule_basis']['matrix_key']}",
                "excerpt": policy_context.get("eligibility", {}).get("reason") or "Eligibility rule applied from approval matrix.",
            },
            {
                "source": "policy/limits.json",
                "section": "caps/per_diem",
                "excerpt": f"max_cap={policy_context['caps']['max_cap']}, per_diem_days={policy_context['per_diem_days']}",
            },
        ]

        return DecisionOutput(
            decision=decision,
            approved_amount=float(amt),
            deductions_rejected=float(deductions_rejected if decision == "PartiallyApprove" else 0.0),
            missing_documents=missing_documents,
            policy_references=policy_refs,
            reason_codes=reason_codes,
            confidence=float(confidence),
            short_explanation=explanation if disallow_reason is None else f"{explanation} ({disallow_reason})",
            tool_trace=tool_trace,
        )
