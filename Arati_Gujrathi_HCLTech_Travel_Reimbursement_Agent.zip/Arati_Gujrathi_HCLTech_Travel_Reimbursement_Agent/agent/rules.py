from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Optional

from .schema import Claim, DecisionOutput


def _parse_iso(d: str) -> datetime:
    return datetime.fromisoformat(d)


def validate_claim_dates(claim: Claim, tool_trace: list[dict[str, Any]]) -> list[str]:
    missing: list[str] = []
    if not claim.travel_start_date:
        missing.append("travel_start_date")
    if not claim.travel_end_date:
        missing.append("travel_end_date")
    if missing:
        return missing

    try:
        start = _parse_iso(claim.travel_start_date)
        end = _parse_iso(claim.travel_end_date)
        if end < start:
            tool_trace.append(
                {"tool": "validate_claim_dates", "issue": "travel_end_date_before_start_date"}
            )
            missing.append("date_range_invalid")
    except Exception:
        tool_trace.append({"tool": "validate_claim_dates", "issue": "date_parse_failed"})
        missing.append("date_range_invalid")

    return missing


def receipt_completeness_check(
    claim: Claim, required_categories: list[str], tool_trace: list[dict[str, Any]]
) -> dict[str, Any]:
    """
    Returns:
      - missing_receipts_categories: categories for which no receipt exists
      - total_receipts_amount: sum of receipt amounts
      - attachments_missing: list of receipt_ids that are not attached
    """
    receipts = claim.receipts or []
    receipt_categories_present = {r.category for r in receipts}

    missing_receipts_categories = [c for c in required_categories if c not in receipt_categories_present]
    attachments_missing = [r.receipt_id for r in receipts if not r.attached]

    total_receipts_amount = sum(r.amount for r in receipts) if receipts else 0.0

    tool_trace.append(
        {
            "tool": "receipt_completeness_check",
            "claim_id": claim.claim_id,
            "missing_receipts_categories": missing_receipts_categories,
            "attachments_missing": attachments_missing,
            "total_receipts_amount": total_receipts_amount,
        }
    )

    return {
        "missing_receipts_categories": missing_receipts_categories,
        "total_receipts_amount": total_receipts_amount,
        "attachments_missing": attachments_missing,
    }


def apply_per_diem_and_limits(
    claim: Claim,
    policy_context: dict[str, Any],
    tool_trace: list[dict[str, Any]],
) -> dict[str, Any]:
    """
    Deterministically compute approved amount based on:
      - eligibility per category/region (from policy_context)
      - max cap for region/category
      - optional per-diem if policy defines it
    """
    # Eligibility
    eligibility = policy_context.get("eligibility", {})
    is_allowed = bool(eligibility.get("allowed", False))
    disallow_reason = eligibility.get("reason") if not is_allowed else None

    # Caps
    caps = policy_context.get("caps", {})
    max_cap = float(caps.get("max_cap", 0.0))
    # Per-diem is modeled as: per_diem_amount * days, if provided. Otherwise use max_cap only.
    per_diem = policy_context.get("per_diem", {})
    per_diem_amount = per_diem.get("amount")
    per_diem_currency = per_diem.get("currency", claim.currency)
    per_diem_days = policy_context.get("per_diem_days", 0)

    # Compute candidate approval limit
    per_diem_limit: Optional[float] = None
    if per_diem_amount is not None and per_diem_days:
        per_diem_limit = float(per_diem_amount) * float(per_diem_days)

    # Determine policy max allowed
    policy_max_allowed_candidates = [max_cap]
    if per_diem_limit is not None:
        policy_max_allowed_candidates.append(per_diem_limit)
    policy_max_allowed = min(policy_max_allowed_candidates) if policy_max_allowed_candidates else 0.0

    requested = max(0.0, float(claim.total_requested_amount))

    if not is_allowed:
        tool_trace.append(
            {
                "tool": "apply_per_diem_and_limits",
                "claim_id": claim.claim_id,
                "allowed": False,
                "disallow_reason": disallow_reason,
            }
        )
        return {
            "allowed": False,
            "policy_max_allowed": policy_max_allowed,
            "approved_amount": 0.0,
            "deductions_rejected": requested,
            "disallow_reason": disallow_reason,
        }

    approved = max(0.0, min(requested, policy_max_allowed))
    deductions_rejected = max(0.0, requested - approved)

    tool_trace.append(
        {
            "tool": "apply_per_diem_and_limits",
            "claim_id": claim.claim_id,
            "requested": requested,
            "policy_max_allowed": policy_max_allowed,
            "approved_amount": approved,
            "deductions_rejected": deductions_rejected,
        }
    )

    return {
        "allowed": True,
        "policy_max_allowed": policy_max_allowed,
        "approved_amount": approved,
        "deductions_rejected": deductions_rejected,
        "disallow_reason": None,
    }


def compute_confidence_and_decision(
    claim: Claim,
    missing_documents: list[str],
    eligibility_allowed: bool,
    deductions_rejected: float,
    allowed_amount: float,
    tool_trace: list[dict[str, Any]],
) -> tuple[str, float, str, float, list[str]]:
    """
    Decide:
      - Reject if eligibility not allowed and/or severe missing docs
      - PartiallyApprove if deductions_rejected > 0 but otherwise allowed
      - ManualReview if ambiguity: missing docs OR conflicting signals
      - Approve if no issues and no deductions
    """
    reason_codes: list[str] = []
    confidence = 0.75

    if missing_documents:
        confidence = 0.35
        reason_codes.append("missing_documents")
        tool_trace.append({"tool": "compute_confidence_and_decision", "missing_documents": missing_documents})
        # Ambiguous: missing documents -> Manual Review
        return ("ManualReview", 0.0, "Missing required documents; route to manual review.", confidence, reason_codes)

    if not eligibility_allowed:
        confidence = 0.9
        reason_codes.append("policy_ineligible")
        tool_trace.append({"tool": "compute_confidence_and_decision", "eligibility_allowed": eligibility_allowed})
        return ("Reject", 0.0, "Claim category/region not eligible under policy.", confidence, reason_codes)

    if deductions_rejected > 0:
        confidence = 0.85
        reason_codes.append("exceeds_policy_limit")
        return (
            "PartiallyApprove",
            allowed_amount,
            "Approved up to policy limits; remainder rejected.",
            confidence,
            reason_codes,
        )

    # Approve
    confidence = 0.9
    reason_codes.append("within_policy_limits")
    return (
        "Approve",
        allowed_amount,
        "Approved: claim is eligible and within policy limits.",
        confidence,
        reason_codes,
    )


def duplicate_detector(claim: Claim, previous_claims: list[dict[str, Any]], tool_trace: list[dict[str, Any]]) -> dict[str, Any]:
    """
    Simple deterministic duplicate detection using:
      (vendor, date, amount, category) if those fields exist in receipts;
      or (possible_duplicate_of) mock field.
    """
    if claim.possible_duplicate_of:
        tool_trace.append({"tool": "duplicate_detector", "claim_id": claim.claim_id, "mock_duplicate_flag": claim.possible_duplicate_of})
        return {"is_duplicate_suspected": True, "duplicate_of": claim.possible_duplicate_of, "confidence": 0.7}

    # Find best receipt signature
    sig = None
    if claim.receipts:
        r0 = claim.receipts[0]
        sig = (r0.vendor.lower().strip(), r0.date, float(r0.amount), r0.category.lower().strip())

    for pc in previous_claims:
        if pc.get("claim_id") == claim.claim_id:
            continue
        if pc.get("possible_duplicate_of") == claim.claim_id:
            continue

        # Match by signature if possible
        if sig and pc.get("receipts"):
            rcp0 = pc["receipts"][0]
            pc_sig = (rcp0["vendor"].lower().strip(), rcp0["date"], float(rcp0["amount"]), rcp0["category"].lower().strip())
            if sig == pc_sig:
                tool_trace.append({"tool": "duplicate_detector", "claim_id": claim.claim_id, "match_claim_id": pc.get("claim_id")})
                return {"is_duplicate_suspected": True, "duplicate_of": pc.get("claim_id"), "confidence": 0.8}

    tool_trace.append({"tool": "duplicate_detector", "claim_id": claim.claim_id, "is_duplicate_suspected": False})
    return {"is_duplicate_suspected": False, "duplicate_of": None, "confidence": 0.1}
