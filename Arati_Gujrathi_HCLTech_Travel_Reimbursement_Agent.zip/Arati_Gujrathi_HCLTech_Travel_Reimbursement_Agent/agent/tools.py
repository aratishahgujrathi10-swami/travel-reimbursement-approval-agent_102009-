from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .policy_store import PolicyStore
from .rules import apply_per_diem_and_limits, duplicate_detector, receipt_completeness_check, validate_claim_dates
from .schema import Claim


@dataclass
class ToolResults:
    tool_trace: list[dict[str, Any]]


class Tools:
    def __init__(self, policy_store: PolicyStore, previous_claims: list[dict[str, Any]] | None = None):
        self.policy_store = policy_store
        self.previous_claims = previous_claims or []

    def required_categories_from_policy(self, claim: Claim) -> list[str]:
        """
        Lightweight modeling: required receipt categories depend on claim.category.
        For demo:
          - Hotel -> needs Hotel + Meals
          - Meals -> needs Meals
          - Taxi -> needs Taxi
          - Other -> needs claim.category
        """
        if claim.category.lower() == "hotel":
            return ["Hotel", "Meals"]
        if claim.category.lower() == "meals":
            return ["Meals"]
        if claim.category.lower() == "taxi":
            return ["Taxi"]
        return [claim.category]

    def tool_validate_dates(self, claim: Claim, tool_trace: list[dict[str, Any]]) -> list[str]:
        return validate_claim_dates(claim, tool_trace)

    def tool_receipt_completeness_check(self, claim: Claim, tool_trace: list[dict[str, Any]]) -> dict[str, Any]:
        required = self.required_categories_from_policy(claim)
        return receipt_completeness_check(claim, required, tool_trace)

    def tool_policy_lookup_and_limits_check(
        self, claim: Claim, tool_trace: list[dict[str, Any]]
    ) -> dict[str, Any]:
        policy_context = self.policy_store.get_policy_context(claim)
        limits_result = apply_per_diem_and_limits(claim, policy_context, tool_trace)
        return {"policy_context": policy_context, "limits_result": limits_result}

    def tool_duplicate_detector(self, claim: Claim, tool_trace: list[dict[str, Any]]) -> dict[str, Any]:
        return duplicate_detector(claim, self.previous_claims, tool_trace)
